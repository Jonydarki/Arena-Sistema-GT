
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class CarreraRelevos extends Evento {
    private List<Inscripcion> participantes;
    private List<Double> tiempos;
    private List<Boolean> descalificados;

    public CarreraRelevos(List<Inscripcion> participantes) {
        super();
        if (participantes == null || participantes.size() < 3) {
            throw new IllegalArgumentException("La carrera necesita al menos tres participantes.");
        }
        this.participantes = new ArrayList<>(participantes);
        this.tiempos = new ArrayList<>();
        this.descalificados = new ArrayList<>();
    }

    @Override
    public void registrarResultado(Scanner scanner) {
        if (estado != EstadoEvento.PROGRAMADO) {
            throw new IllegalStateException(
                "La carrera debe estar programada antes de registrar resultados.");
        }
        tiempos.clear();
        descalificados.clear();
        System.out.println("\n==== Resultados De Relevos ====");

        for (Inscripcion participante : participantes) {
            System.out.println(
                "\nParticipante: "
                + participante.getParticipante().getNombre());
            System.out.print("¿Está descalificado? (S/N): ");
            String respuesta = scanner.next();

            boolean descalificado =
            respuesta.equalsIgnoreCase("S");
            descalificados.add(descalificado);

            if (descalificado) {
                tiempos.add(Double.MAX_VALUE);
            } else {
                double tiempo;
                do {
                    System.out.print("Tiempo registrado en segundos: ");
                    tiempo = scanner.nextDouble();
                    if (tiempo <= 0) {
                        System.out.println(
                            "El tiempo debe ser mayor que cero.");
                    }
                } while (tiempo <= 0);
                tiempos.add(tiempo);
            }
        }
        List<Integer> posiciones = new ArrayList<>();

        for (int i = 0; i < participantes.size(); i++) {
            posiciones.add(i);
        }

        Collections.sort(posiciones, (a, b) -> Double.compare(tiempos.get(a), tiempos.get(b)));

        int puntos = participantes.size();

        for (int posicion : posiciones) {
            if (descalificados.get(posicion)) {
                participantes.get(posicion).actualizarEstadisticas(
                    0, 0, false);
            } else {
                participantes.get(posicion).actualizarEstadisticas(
                    puntos, 0, puntos == participantes.size());
                puntos--;
            }
        }
        finalizarEvento();
        System.out.println("\nResultados registrados correctamente.");
        mostrarResultados(posiciones);
    }

    private void mostrarResultados(List<Integer> posiciones) {
        System.out.println("\n--- CLASIFICACIÓN FINAL ---");
        int puesto = 1;

        for (int posicion : posiciones) {
            System.out.print(puesto + ". " + participantes.get(posicion).getParticipante().getNombre());
            if (descalificados.get(posicion)) {
                System.out.println(" | DESCALIFICADO");
            } else {
                System.out.println(
                    " | Tiempo: " + tiempos.get(posicion) + " segundos");
            }
            puesto++;
        }
    }

    @Override
    public boolean involucraParticipante(Participante participante) {
        for (Inscripcion inscripcion : participantes) {
            if (inscripcion.getParticipante() == participante) {
                return true;
            }
        }
        return false;
    }
}