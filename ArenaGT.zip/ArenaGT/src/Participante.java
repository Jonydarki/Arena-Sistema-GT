
public class Participante {
    private String codigo;
    private String nombre;
    private Empresa empresa;

    public Participante(String codigo, String nombre, Empresa empresa) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío.");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (empresa == null) {
            throw new IllegalArgumentException("El participante debe pertenecer a una empresa.");
        }
        this.codigo = codigo;
        this.nombre = nombre;
        this.empresa = empresa;
        empresa.agregarParticipante(this);
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    @Override
    public String toString() {
        return "Código: " + codigo + " | Nombre: " + nombre + " | Empresa: " + empresa.getNombre();
    }
}
