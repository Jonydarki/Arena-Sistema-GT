
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Empresa {
    private String nombre;
    private List<Participante> participantes;

    public Empresa(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la empresa no puede estar vacío.");
        }
        this.nombre = nombre;
        this.participantes = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void agregarParticipante(Participante participante) {
        if (participante == null) {
            throw new IllegalArgumentException("El participante no puede ser nulo.");
        }
        if (participantes.contains(participante)) {
            throw new IllegalArgumentException("El participante ya pertenece a esta empresa.");
        }
        participantes.add(participante);
    }

    public List<Participante> getParticipantes() {
        return Collections.unmodifiableList(participantes);
    }

    @Override
    public String toString() {
        return "Empresa: " + nombre +
               " | Participantes: " + participantes.size();
    }
}