import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static SistemaGT sistema = new SistemaGT();
    public static void main(String[] args) {
        cargarDatosIniciales();
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            try {
                switch (opcion) {
                    case 1:
                        cotizarInscripcion();
                        break;
                    case 2:
                        registrarParticipante();
                        break;
                    case 3:
                        crearTorneo();
                        break;
                    case 4:
                        inscribirParticipante();
                        break;
                    case 5:
                        cerrarInscripciones();
                        break;
                    case 6:
                        programarEvento();
                        break;
                    case 7:
                        reprogramarEvento();
                        break;
                    case 8:
                        registrarResultado();
                        break;
                    case 9:
                        consultarTorneo();
                        break;
                    case 10:
                        consultarParticipante();
                        break;
                    case 11:
                        consultarCalendarios();
                        break;
                    case 12:
                        sistema.generarRankingEmpresas();
                        break;
                    case 13:
                        sistema.generarReporteIngresos();
                        break;
                    case 0:
                        System.out.println("Saliendo de ArenaGT...");
                        break;

                    default:
                        System.out.println("Opción no válida.");
                }

            } catch (Exception e) {
                System.out.println("Operación rechazada: " + e.getMessage());
            }

        } while (opcion != 0);
    }

    private static void mostrarMenu() {
        System.out.println("\n========== ARENAGT ==========");
        System.out.println("1. Cotizar inscripción");
        System.out.println("2. Registrar participante");
        System.out.println("3. Crear torneo");
        System.out.println("4. Inscribir participante");
        System.out.println("5. Cerrar inscripciones");
        System.out.println("6. Programar evento");
        System.out.println("7. Reprogramar evento");
        System.out.println("8. Registrar resultado");
        System.out.println("9. Consultar torneo y tabla");
        System.out.println("10. Consultar participante");
        System.out.println("11. Consultar calendarios");
        System.out.println("12. Ranking de empresas");
        System.out.println("13. Reporte de ingresos y premios");
        System.out.println("0. Salir");
        System.out.println("=============================");
    }

    private static void cargarDatosIniciales() {
        Empresa empresaA = new Empresa("Electra");
        Empresa empresaB = new Empresa("Toyora");
        Empresa empresaC = new Empresa("Cementos Progresos");

        Participante p1 = new Participante("P001", "Titanes", empresaA);
        Participante p2 = new Participante("P002", "Halcones", empresaA);
        Participante p3 = new Participante("P003", "Leones", empresaB);
        Participante p4 = new Participante("P004", "Dragones", empresaB);
        Participante p5 = new Participante("P005", "Panteras", empresaC);
        Participante p6 = new Participante("P006", "Cóndores", empresaC);

        sistema.registrarParticipante(p1);
        sistema.registrarParticipante(p2);
        sistema.registrarParticipante(p3);
        sistema.registrarParticipante(p4);
        sistema.registrarParticipante(p5);
        sistema.registrarParticipante(p6);

        Torneo futbol = sistema.crearTorneo(
                "T001", "Copa Futbol Sala", new FutbolSala());

        Torneo penales = sistema.crearTorneo(
                "T002", "Copa Futbol Sala Penales",
                new FutbolSalaPenales());

        Torneo baloncesto = sistema.crearTorneo(
                "T003", "Copa Baloncesto", new Baloncesto());

        Torneo voleibol = sistema.crearTorneo(
                "T004", "Copa Voleibol", new Voleibol());

        Torneo relevos = sistema.crearTorneo(
                "T005", "Copa Relevos", new Relevos());

        List<Participante> lista = new ArrayList<>();
        lista.add(p1);
        lista.add(p2);
        lista.add(p3);
        lista.add(p4);
        lista.add(p5);
        lista.add(p6);

        for (Participante p : lista) {
            futbol.inscribirParticipante(p);
            penales.inscribirParticipante(p);
            baloncesto.inscribirParticipante(p);
            voleibol.inscribirParticipante(p);
            relevos.inscribirParticipante(p);
        }

        futbol.cerrarInscripciones();
        penales.cerrarInscripciones();

        programarEventosIniciales(futbol, 0);
        programarEventosIniciales(penales, 20);

        if (!penales.getEventos().isEmpty()) {
            Evento eventoInicial = penales.getEventos().get(0);
            sistema.registrarResultado(eventoInicial, new Scanner("1 1 3 2"));
        }
        System.out.println("\nDatos iniciales cargados correctamente.");
    }

    private static void programarEventosIniciales(Torneo torneo, int desplazamiento) {
        List<Evento> eventos = torneo.getEventos();
        for (int i = 0; i < eventos.size(); i++) {
            LocalDate fecha = LocalDate.of(2026, 12, 1).plusDays(desplazamiento + i / 12);
            int hora = 8 + (i % 12);
            String sede = "Cancha " + (i + 1);
            sistema.programarEvento(eventos.get(i), fecha, hora, sede);
        }
    }

    private static void cotizarInscripcion() {
        Disciplina disciplina = seleccionarDisciplina();
        int cantidad = leerEntero("Cantidad de participantes: ");
        System.out.println("Total de la cotización: Q" + sistema.cotizarInscripcion(disciplina, cantidad));
    }

    private static void registrarParticipante() {
        String codigo = leerTexto("Código: ");
        String nombre = leerTexto("Nombre del participante: ");
        for (Participante p : sistema.getParticipantes()) {
            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                throw new IllegalArgumentException("El código ya existe.");
            }
        }

        String nombreEmpresa = leerTexto("Nombre de la empresa: ");
        Empresa empresa = null;

        for (Empresa e : sistema.getEmpresas()) {
            if (e.getNombre().equalsIgnoreCase(nombreEmpresa)) {
                empresa = e;
                break;
            }
        }

        if (empresa == null) {
            empresa = new Empresa(nombreEmpresa);
        }

        Participante participante = new Participante(codigo, nombre, empresa);
        sistema.registrarParticipante(participante);
        System.out.println("Participante registrado correctamente.");
    }

    private static void crearTorneo() {
        String codigo = leerTexto("Código del torneo: ");
        String nombre = leerTexto("Nombre del torneo: ");
        Disciplina disciplina = seleccionarDisciplina();
        sistema.crearTorneo(codigo, nombre, disciplina);
        System.out.println("Torneo creado correctamente.");
    }

    private static Disciplina seleccionarDisciplina() {
        System.out.println("\nSeleccione una disciplina:");
        System.out.println("1. Fútbol sala");
        System.out.println("2. Fútbol sala con penales");
        System.out.println("3. Baloncesto");
        System.out.println("4. Voleibol");
        System.out.println("5. Relevos");
        int opcion = leerEntero("Opción: ");

        switch (opcion) {
            case 1:
                return new FutbolSala();
            case 2:
                return new FutbolSalaPenales();
            case 3:
                return new Baloncesto();
            case 4:
                return new Voleibol();
            case 5:
                return new Relevos();
            default:
                throw new IllegalArgumentException("Disciplina no válida.");
        }
    }

    private static void inscribirParticipante() {
        Torneo torneo = seleccionarTorneo();
        Participante participante = seleccionarParticipante();
        sistema.inscribirParticipante(torneo, participante);
        System.out.println("Inscripción realizada correctamente.");
    }

    private static void cerrarInscripciones() {
        Torneo torneo = seleccionarTorneo();
        sistema.cerrarInscripciones(torneo);
        System.out.println("Inscripciones cerradas. Eventos generados.");
    }

    private static void programarEvento() {
        Evento evento = seleccionarEvento();
        LocalDate fecha = leerFecha();
        int hora = leerEntero("Hora (0-23): ");
        String sede = leerTexto("Sede: ");
        sistema.programarEvento(evento, fecha, hora, sede);
        System.out.println("Evento programado correctamente.");
    }

    private static void reprogramarEvento() {
        Evento evento = seleccionarEvento();
        LocalDate fecha = leerFecha();
        int hora = leerEntero("Nueva hora (0-23): ");
        String sede = leerTexto("Nueva sede: ");
        sistema.reprogramarEvento(evento, fecha, hora, sede);
        System.out.println("Evento reprogramado correctamente.");
    }

    private static void registrarResultado() {
        Evento evento = seleccionarEvento();
        sistema.registrarResultado(evento, scanner);
        scanner.nextLine();
        System.out.println("Resultado registrado correctamente.");
    }

    private static void consultarTorneo() {
        Torneo torneo = seleccionarTorneo();
        System.out.println("\n" + torneo);
        sistema.mostrarTablaPosiciones(torneo);
        sistema.mostrarCalendarioTorneo(torneo);
    }

    private static void consultarParticipante() {
        Participante participante = seleccionarParticipante();
        System.out.println("\n" + participante);
        sistema.mostrarCalendarioParticipante(participante);
    }

    private static void consultarCalendarios() {
        System.out.println("\n1. Calendario general");
        System.out.println("2. Calendario de un torneo");
        System.out.println("3. Calendario de un participante");
        int opcion = leerEntero("Seleccione una opción: ");
        
        switch (opcion) {
            case 1:
                sistema.mostrarCalendario();
                break;
            case 2:
                sistema.mostrarCalendarioTorneo(seleccionarTorneo());
                break;
            case 3:
                sistema.mostrarCalendarioParticipante(seleccionarParticipante());
                break;
            default:
                System.out.println("Opción no válida.");
        }
    }

    private static Torneo seleccionarTorneo() {
        List<Torneo> torneos = sistema.getTorneos();
        if (torneos.isEmpty()) {
            throw new IllegalStateException("No hay torneos registrados.");
        }
        System.out.println("\n===== TORNEOS =====");

        for (int i = 0; i < torneos.size(); i++) {
            System.out.println((i + 1) + ". " + torneos.get(i));
        }
        int opcion = leerEntero("Seleccione un torneo: ");

        if (opcion < 1 || opcion > torneos.size()) {
            throw new IllegalArgumentException("Torneo no válido.");
        }
        return torneos.get(opcion - 1);
    }

    private static Participante seleccionarParticipante() {
        List<Participante> participantes = sistema.getParticipantes();
        if (participantes.isEmpty()) {
            throw new IllegalStateException("No hay participantes registrados.");
        }
        System.out.println("\n===== PARTICIPANTES =====");

        for (int i = 0; i < participantes.size(); i++) {
            System.out.println((i + 1) + ". " + participantes.get(i));
        }
        int opcion = leerEntero("Seleccione un participante: ");

        if (opcion < 1 || opcion > participantes.size()) {
            throw new IllegalArgumentException("Participante no válido.");
        }
        return participantes.get(opcion - 1);
    }

    private static Evento seleccionarEvento() {
        List<Evento> eventos = new ArrayList<>();
        for (Torneo torneo : sistema.getTorneos()) {
            eventos.addAll(torneo.getEventos());
        }

        if (eventos.isEmpty()) {
            throw new IllegalStateException("No hay eventos registrados.");
        }
        System.out.println("\n===== EVENTOS =====");

        for (int i = 0; i < eventos.size(); i++) {
            System.out.println((i + 1) + ". " + eventos.get(i));
        }

        int opcion = leerEntero("Seleccione un evento: ");

        if (opcion < 1 || opcion > eventos.size()) {
            throw new IllegalArgumentException("Evento no válido.");
        }

        return eventos.get(opcion - 1);
    }

    private static String leerTexto(String mensaje) {
        System.out.print(mensaje);
        String texto = scanner.nextLine().trim();
        if (texto.isEmpty()) {
            throw new IllegalArgumentException(
                    "El campo no puede estar vacío.");
        }
        return texto;
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un número entero.");
            }
        }
    }

    private static LocalDate leerFecha() {
        while (true) {
            System.out.print("Fecha (AAAA-MM-DD): ");
            try {
                return LocalDate.parse(scanner.nextLine().trim());
            } catch (Exception e) {
                System.out.println("Fecha inválida. Ejemplo: 2026-12-15");
            }
        }
    }
}