public class Inscripcion implements Comparable<Inscripcion> {
    private Participante participante;
    private int puntosTabla;
    private int diferencia;
    private int victorias;

    public Inscripcion(Participante participante) {
        if (participante == null) {
            throw new IllegalArgumentException("El participante no puede ser nulo.");
        }
        this.participante = participante;
        this.puntosTabla = 0;
        this.diferencia = 0;
        this.victorias = 0;
    }

    public Participante getParticipante() {
        return participante;
    }

    public int getPuntosTabla() {
        return puntosTabla;
    }

    public int getDiferencia() {
        return diferencia;
    }

    public int getVictorias() {
        return victorias;
    }

    public void actualizarEstadisticas(int puntos, int diferencia, boolean victoria) {
        this.puntosTabla += puntos;
        this.diferencia += diferencia;
        if (victoria) {
            this.victorias++;
        }
    }

    @Override
    public int compareTo(Inscripcion otra) {
        int resultado = Integer.compare(otra.puntosTabla, this.puntosTabla);
        if (resultado == 0) {
            resultado = Integer.compare(otra.diferencia, this.diferencia);
        }
        if (resultado == 0) {
            resultado = Integer.compare(otra.victorias, this.victorias);
        }
        if (resultado == 0) {
            resultado = this.participante.getNombre()
                    .compareToIgnoreCase(otra.participante.getNombre());
        }
        return resultado;
    }

    @Override
    public String toString() {
        return participante.getNombre()
                + " | Puntos: " + puntosTabla
                + " | Diferencia: " + diferencia
                + " | Victorias: " + victorias;
    }
}
