import java.util.Scanner;

public abstract class Encuentro extends Evento {
    protected Inscripcion participanteLocal;
    protected Inscripcion participanteVisitante;

    public Encuentro(Inscripcion local, Inscripcion visitante) {
        super();
        if (local == null || visitante == null) {
            throw new IllegalArgumentException(
                "Las inscripciones no pueden ser nulas.");
        }
        if (local == visitante) {
            throw new IllegalArgumentException(
                "Un participante no puede enfrentarse a sí mismo.");
        }
        this.participanteLocal = local;
        this.participanteVisitante = visitante;
    }

    public Inscripcion getParticipanteLocal() {
        return participanteLocal;
    }

    public Inscripcion getParticipanteVisitante() {
        return participanteVisitante;
    }

    protected void validarRegistroResultado() {
        if (estado != EstadoEvento.PROGRAMADO) {
            throw new IllegalStateException(
                "El evento debe estar programado antes de registrar el resultado.");
        }
    }

    protected int leerMarcador(Scanner scanner, String mensaje) {
        int valor;
        do {
            System.out.print(mensaje);
            valor = scanner.nextInt();
            if (valor < 0) {
                System.out.println("El marcador no puede ser negativo.");
            }

        } while (valor < 0);
        return valor;
    }

    @Override
    public boolean involucraParticipante(Participante participante) {
        return participanteLocal.getParticipante() == participante
        || participanteVisitante.getParticipante() == participante;
    }
}