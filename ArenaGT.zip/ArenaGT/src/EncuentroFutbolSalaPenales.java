
import java.util.Scanner;

public class EncuentroFutbolSalaPenales extends EncuentroFutbolSala {
    public EncuentroFutbolSalaPenales(Inscripcion local, Inscripcion visitante) {
        super(local, visitante);
    }

    @Override
    public void registrarResultado(Scanner scanner) {
        validarRegistroResultado();
        System.out.println("\n==== Futbol Sala Con Penales ====");
        int golesLocal = leerMarcador(scanner, "Goles del participante local: ");

        int golesVisitante = leerMarcador(scanner, "Goles del participante visitante: ");

        if (golesLocal > golesVisitante) {
            participanteLocal.actualizarEstadisticas(
                3, golesLocal - golesVisitante, true);

            participanteVisitante.actualizarEstadisticas(
                0, golesVisitante - golesLocal, false);

        } else if (golesVisitante > golesLocal) {
            participanteVisitante.actualizarEstadisticas(
                3, golesVisitante - golesLocal, true);

            participanteLocal.actualizarEstadisticas(
                0, golesLocal - golesVisitante, false);

        } else {
            System.out.println("Empate. Se realizará una tanda de penales.");

            int penalesLocal;
            int penalesVisitante;

            do {
                penalesLocal = leerMarcador(
                    scanner, "Penales convertidos por el local: ");

                penalesVisitante = leerMarcador(
                    scanner, "Penales convertidos por el visitante: ");

                if (penalesLocal == penalesVisitante) {
                    System.out.println(
                        "La tanda debe tener un ganador. Intente nuevamente.");
                }

            } while (penalesLocal == penalesVisitante);

            if (penalesLocal > penalesVisitante) {
                participanteLocal.actualizarEstadisticas(
                    2, 0, true);

                participanteVisitante.actualizarEstadisticas(
                    1, 0, false);

            } else {
                participanteVisitante.actualizarEstadisticas(
                    2, 0, true);

                participanteLocal.actualizarEstadisticas(
                    1, 0, false);
            }
        }

        finalizarEvento();
        System.out.println("Resultado registrado correctamente.");
    }
}