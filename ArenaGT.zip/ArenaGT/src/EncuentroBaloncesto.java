
import java.util.Scanner;

public class EncuentroBaloncesto extends Encuentro {
    public EncuentroBaloncesto(Inscripcion local, Inscripcion visitante) {
        super(local, visitante);
    }

    @Override
    public void registrarResultado(Scanner scanner) {
        validarRegistroResultado();
        System.out.println("\n--- RESULTADO BALONCESTO ---");
        int puntosLocal = leerMarcador(scanner, "Puntos del participante local: ");
        int puntosVisitante = leerMarcador(scanner, "Puntos del participante visitante: ");
        
        if (puntosLocal == puntosVisitante) {
            throw new IllegalArgumentException(
                "Un encuentro de baloncesto no puede terminar empatado.");
        }

        if (puntosLocal > puntosVisitante) {
            participanteLocal.actualizarEstadisticas(
                3, puntosLocal - puntosVisitante, true);

            participanteVisitante.actualizarEstadisticas(
                0, puntosVisitante - puntosLocal, false);

        } else {
            participanteVisitante.actualizarEstadisticas(
                3, puntosVisitante - puntosLocal, true);

            participanteLocal.actualizarEstadisticas(
                0, puntosLocal - puntosVisitante, false);
        }
        finalizarEvento();
        System.out.println("Resultado registrado correctamente.");
    }
}