
import java.util.Scanner;

public class EncuentroFutbolSala extends Encuentro {
    public EncuentroFutbolSala(Inscripcion local, Inscripcion visitante) {
        super(local, visitante);
    }

    @Override
    public void registrarResultado(Scanner scanner) {
        validarRegistroResultado();

        System.out.println("\n==== Resultado Futbol Sala ====");

        int golesLocal = leerMarcador(
            scanner, "Goles del participante local: ");

        int golesVisitante = leerMarcador(
            scanner, "Goles del participante visitante: ");

        if (golesLocal > golesVisitante) {
            participanteLocal.actualizarEstadisticas(
                3, golesLocal - golesVisitante, true);

            participanteVisitante.actualizarEstadisticas(
                0, golesVisitante - golesLocal, false);

        } else if (golesVisitante > golesLocal) {
            participanteVisitante.actualizarEstadisticas(
                3, golesVisitante - golesLocal, true);

            participanteLocal.actualizarEstadisticas(
                0, golesLocal - golesVisitante, false);

        } else {
            participanteLocal.actualizarEstadisticas(
                1, 0, false);

            participanteVisitante.actualizarEstadisticas(
                1, 0, false);
        }

        finalizarEvento();
        System.out.println("Resultado registrado correctamente.");
    }
}
