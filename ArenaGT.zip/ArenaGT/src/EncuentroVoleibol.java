import java.util.Scanner;

public class EncuentroVoleibol extends Encuentro {
    public EncuentroVoleibol(Inscripcion local, Inscripcion visitante) {
        super(local, visitante);
    }

    @Override
    public void registrarResultado(Scanner scanner) {
        validarRegistroResultado();
        System.out.println("\n==== Resultado Voleibol ====");

        int setsLocal = leerMarcador(scanner, "Sets ganados por el participante local: ");

        int setsVisitante = leerMarcador(scanner, "Sets ganados por el participante visitante: ");

        boolean resultadoValido = (setsLocal == 3 && setsVisitante >= 0 && setsVisitante <= 2)
            || (setsVisitante == 3 && setsLocal >= 0 && setsLocal <= 2);

        if (!resultadoValido) {
            throw new IllegalArgumentException(
                "Resultado inválido. Un participante debe ganar 3 sets.");
        }

        if (setsLocal > setsVisitante) {
            participanteLocal.actualizarEstadisticas(
                3, setsLocal - setsVisitante, true);

            participanteVisitante.actualizarEstadisticas(
                0, setsVisitante - setsLocal, false);

        } else {
            participanteVisitante.actualizarEstadisticas(
                3, setsVisitante - setsLocal, true);

            participanteLocal.actualizarEstadisticas(
                0, setsLocal - setsVisitante, false);
        }

        finalizarEvento();
        System.out.println("Resultado registrado correctamente.");
    }
}