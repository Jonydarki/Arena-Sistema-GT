import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class SistemaGT {
    private List<Participante> participantes;
    private List<Empresa> empresas;
    private List<Torneo> torneos;
    private BigDecimal ingresosTotales;
    private BigDecimal premiosTotales;
    private Map<String, BigDecimal> ingresosPorDisciplina;

    public SistemaGT() {
        participantes = new ArrayList<>();
        empresas = new ArrayList<>();
        torneos = new ArrayList<>();

        ingresosTotales = BigDecimal.ZERO;
        premiosTotales = BigDecimal.ZERO;

        ingresosPorDisciplina = new HashMap<>();
    }

    public void registrarParticipante(Participante participante) {
        if (participante == null) {
            throw new IllegalArgumentException("Participante inválido.");
        }
        for (Participante p : participantes) {
            if (p.getCodigo().equalsIgnoreCase(participante.getCodigo())) {
                throw new IllegalArgumentException("El código ya existe.");
            }
        }
        participantes.add(participante);

        boolean empresaRegistrada = false;

        for (Empresa e : empresas) {
            if (e.getNombre().equalsIgnoreCase(
                    participante.getEmpresa().getNombre())) {
                empresaRegistrada = true;
                break;
            }
        }
        if (!empresaRegistrada) {
            empresas.add(participante.getEmpresa());
        }
    }


    public Torneo crearTorneo(String codigo, String nombre, Disciplina disciplina) {

        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("Código inválido.");
        }
        for (Torneo t : torneos) {
            if (t.getCodigo().equalsIgnoreCase(codigo)) {
                throw new IllegalArgumentException("El código del torneo ya existe.");
            }
        }
        Torneo torneo = new Torneo(codigo, nombre, disciplina);
        torneos.add(torneo);
        return torneo;
    }

    public BigDecimal cotizarInscripcion(Disciplina disciplina, int cantidad) {
        if (disciplina == null) {
            throw new IllegalArgumentException("Disciplina inválida.");
        }
        disciplina.validarInscripcion(cantidad);
        return disciplina.getCuota().multiply(BigDecimal.valueOf(cantidad));
    }

    public void inscribirParticipante(Torneo torneo, Participante participante) { 
        if (!torneos.contains(torneo)) {
            throw new IllegalArgumentException("El torneo no está registrado.");
        }

        if (!participantes.contains(participante)) {
            throw new IllegalArgumentException("El participante no está registrado.");
        }

        torneo.inscribirParticipante(participante);

        BigDecimal cuota = torneo.getDisciplina().getCuota();

        ingresosTotales = ingresosTotales.add(cuota);

        String disciplina = torneo.getDisciplina().getNombre();

        BigDecimal ingresoActual = ingresosPorDisciplina.getOrDefault(disciplina, BigDecimal.ZERO);

        ingresosPorDisciplina.put(disciplina, ingresoActual.add(cuota));
    }

    public void cerrarInscripciones(Torneo torneo) {
        if (!torneos.contains(torneo)) {
            throw new IllegalArgumentException("Torneo no registrado.");
        }
        torneo.cerrarInscripciones();
    }


    private boolean existeConflicto(Evento evento, LocalDate fecha, int hora, String sede) {
        for (Torneo torneo : torneos) {
            for (Evento otro : torneo.getEventos()) {
                if (otro == evento || !otro.estaProgramado()) {
                    continue;
                }

                boolean mismoHorario =
                        otro.getFecha().equals(fecha)
                        && otro.getHora() == hora;

                if (mismoHorario) {
                    if (otro.getSede().equalsIgnoreCase(sede)) {
                        return true;
                    }
                    for (Participante p : participantes) {
                        if (evento.involucraParticipante(p)
                                && otro.involucraParticipante(p)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    private void validarEventoRegistrado(Evento evento) {
        for (Torneo torneo : torneos) {
            if (torneo.getEventos().contains(evento)) {
                return;
            }
        }
        throw new IllegalArgumentException("El evento no pertenece al sistema.");
    }

    public void programarEvento(Evento evento, LocalDate fecha, int hora, String sede) {
        validarEventoRegistrado(evento);
        if (existeConflicto(evento, fecha, hora, sede)) {
            throw new IllegalArgumentException("Conflicto de sede o de participante.");
        }
        evento.programar(fecha, hora, sede);
    }

    public void reprogramarEvento(Evento evento, LocalDate fecha, int hora, String sede) {
        validarEventoRegistrado(evento);
        if (existeConflicto(evento, fecha, hora, sede)) {
            throw new IllegalArgumentException("Conflicto de sede o de participante.");
        }
        evento.reprogramar(fecha, hora, sede);
    }

    public void registrarResultado(Evento evento, Scanner scanner) {
        validarEventoRegistrado(evento);
        Torneo torneoDelEvento = null;
        for (Torneo torneo : torneos) {
            if (torneo.getEventos().contains(evento)) {
                torneoDelEvento = torneo;
                break;
            }
        }

        EstadoTorneo estadoAnterior = torneoDelEvento.getEstado();

        evento.registrarResultado(scanner);

        torneoDelEvento.verificarFinalizacion();

        if (estadoAnterior != EstadoTorneo.FINALIZADO
                && torneoDelEvento.getEstado() == EstadoTorneo.FINALIZADO) {
            premiosTotales = premiosTotales.add(torneoDelEvento.getPremio());
        }
    }

    public void mostrarCalendario() {
        List<Evento> calendario = new ArrayList<>();
        for (Torneo torneo : torneos) {
            for (Evento evento : torneo.getEventos()) {
                if (evento.estaProgramado()) {
                    calendario.add(evento);
                }
            }
        }
        Collections.sort(calendario);
        System.out.println("\n===== CALENDARIO GENERAL =====");

        for (Evento evento : calendario) {
            System.out.println(evento);
        }
    }

    public void mostrarCalendarioTorneo(Torneo torneo) {
        List<Evento> calendario = new ArrayList<>();
        for (Evento evento : torneo.getEventos()) {
            if (evento.estaProgramado()) {
                calendario.add(evento);
            }
        }
        Collections.sort(calendario);
        System.out.println("\n===== CALENDARIO DEL TORNEO =====");
        for (Evento evento : calendario) {
            System.out.println(evento);
        }
    }

    public void mostrarCalendarioParticipante(Participante participante) {
        List<Evento> calendario = new ArrayList<>();
        for (Torneo torneo : torneos) {
            for (Evento evento : torneo.getEventos()) {
                if (evento.estaProgramado()
                        && evento.involucraParticipante(participante)) {
                    calendario.add(evento);
                }
            }
        }
        Collections.sort(calendario);
        System.out.println("\n===== CALENDARIO DEL PARTICIPANTE =====");
        for (Evento evento : calendario) {
            System.out.println(evento);
        }
    }

    public void mostrarTablaPosiciones(Torneo torneo) {
        System.out.println("\n===== TABLA DE POSICIONES =====");
        System.out.println("Torneo: " + torneo.getNombre());
        List<Inscripcion> tabla = torneo.obtenerTablaPosiciones();

        for (int i = 0; i < tabla.size(); i++) {
            System.out.println((i + 1) + ". " + tabla.get(i));
        }

        if (torneo.getEstado() == EstadoTorneo.FINALIZADO
                && !tabla.isEmpty()) {
            System.out.println("Campeón: " + tabla.get(0).getParticipante().getNombre());
        }
    }

    public void generarRankingEmpresas() {
        Map<Empresa, Integer> puntosEmpresas = new HashMap<>();
        for (Empresa empresa : empresas) {
            puntosEmpresas.put(empresa, 0);
        }

        for (Torneo torneo : torneos) {
            for (Inscripcion inscripcion : torneo.getInscripciones()) {
                Empresa empresa = inscripcion.getParticipante().getEmpresa();
                int puntos = puntosEmpresas.getOrDefault(empresa, 0);
                puntosEmpresas.put(empresa, puntos + inscripcion.getPuntosTabla());
            }
        }

        List<Map.Entry<Empresa, Integer>> ranking =
                new ArrayList<>(puntosEmpresas.entrySet());

        ranking.sort((a, b) -> {
            int resultado = Integer.compare(b.getValue(), a.getValue());

            if (resultado == 0) {
                resultado = a.getKey().getNombre().compareToIgnoreCase(b.getKey().getNombre());
            }

            return resultado;
        });
        System.out.println("\n===== RANKING DE EMPRESAS =====");

        int posicion = 1;

        for (Map.Entry<Empresa, Integer> entrada : ranking) {
            System.out.println(posicion++ + ". "
                    + entrada.getKey().getNombre()
                    + " | Puntos: " + entrada.getValue());
        }
    }

    public void generarReporteIngresos() {
        System.out.println("\n===== REPORTE DE INGRESOS =====");
        for (Map.Entry<String, BigDecimal> entrada : ingresosPorDisciplina.entrySet()) {
            System.out.println(entrada.getKey() + ": Q" + entrada.getValue().setScale(2, java.math.RoundingMode.HALF_UP));
        }

        System.out.println("Ingresos totales: Q" + ingresosTotales.setScale(2, java.math.RoundingMode.HALF_UP));

        System.out.println("Premios entregados: Q" + premiosTotales.setScale(2, java.math.RoundingMode.HALF_UP));
    }

    public List<Participante> getParticipantes() {
        return Collections.unmodifiableList(participantes);
    }

    public List<Empresa> getEmpresas() {
        return Collections.unmodifiableList(empresas);
    }

    public List<Torneo> getTorneos() {
        return Collections.unmodifiableList(torneos);
    }

    public BigDecimal getIngresosTotales() {
        return ingresosTotales;
    }

    public BigDecimal getPremiosTotales() {
        return premiosTotales;
    }
}