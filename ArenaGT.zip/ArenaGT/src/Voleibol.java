
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Voleibol extends Disciplina {
    public Voleibol() {
        super("Voleibol", new BigDecimal("450"), 4, 6);
    }

    @Override
    public List<Evento> crearEventos(List<Inscripcion> participantes) {
        List<Evento> eventos = new ArrayList<>();
        for (int i = 0; i < participantes.size(); i++) {
            for (int j = i + 1; j < participantes.size(); j++) {
                eventos.add(new EncuentroVoleibol(
                        participantes.get(i),
                        participantes.get(j)
                ));
            }
        }
        return eventos;
    }
}
