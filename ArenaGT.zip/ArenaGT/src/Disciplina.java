import java.math.BigDecimal;
import java.util.List;

public abstract class Disciplina {
    protected String nombre;
    protected BigDecimal cuota;
    protected int minimoParticipantes;
    protected int maximoParticipantes;

    public Disciplina(String nombre, BigDecimal cuota, int minimoParticipantes, int maximoParticipantes) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }

        if (cuota == null || cuota.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("La cuota debe ser mayor que cero.");
        }

        if (minimoParticipantes <= 0
                || maximoParticipantes < minimoParticipantes) {
            throw new IllegalArgumentException("Los límites de participantes no son válidos.");
        }

        this.nombre = nombre;
        this.cuota = cuota;
        this.minimoParticipantes = minimoParticipantes;
        this.maximoParticipantes = maximoParticipantes;
    }

    public String getNombre() {
        return nombre;
    }

    public BigDecimal getCuota() {
        return cuota;
    }

    public int getMinimoParticipantes() {
        return minimoParticipantes;
    }

    public int getMaximoParticipantes() {
        return maximoParticipantes;
    }

    public boolean validarInscripcion(int cantidad) {
        return cantidad >= minimoParticipantes
                && cantidad <= maximoParticipantes;
    }

    public abstract List<Evento> crearEventos(List<Inscripcion> participantes);
}
