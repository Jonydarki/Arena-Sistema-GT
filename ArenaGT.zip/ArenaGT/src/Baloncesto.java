
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Baloncesto extends Disciplina {
    public Baloncesto() {
        super("Baloncesto", new BigDecimal("500"), 4, 6);
    }

    @Override
    public List<Evento> crearEventos(List<Inscripcion> participantes) {
        List<Evento> eventos = new ArrayList<>();
        for (int i = 0; i < participantes.size(); i++) {
            for (int j = i + 1; j < participantes.size(); j++) {
                eventos.add(new EncuentroBaloncesto(
                        participantes.get(i),
                        participantes.get(j)
                ));
            }
        }
        return eventos;
    }
}
