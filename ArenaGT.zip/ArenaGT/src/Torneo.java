import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Torneo {
    private String codigo;
    private String nombre;
    private Disciplina disciplina;
    private List<Inscripcion> inscripciones;
    private List<Evento> eventos;
    private EstadoTorneo estado;
    private BigDecimal premio;

    public Torneo(String codigo, String nombre, Disciplina disciplina) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío.");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (disciplina == null) {
            throw new IllegalArgumentException("Debe seleccionar una disciplina.");
        }
        this.codigo = codigo;
        this.nombre = nombre;
        this.disciplina = disciplina;
        this.inscripciones = new ArrayList<>();
        this.eventos = new ArrayList<>();
        this.estado = EstadoTorneo.EN_INSCRIPCION;
        this.premio = BigDecimal.ZERO;
    }

    
    public void inscribirParticipante(Participante participante) {
        if (estado != EstadoTorneo.EN_INSCRIPCION) {
            throw new IllegalStateException("El torneo ya no acepta inscripciones.");
        }
        if (participante == null) {
            throw new IllegalArgumentException("El participante no puede ser nulo.");
        }
        if (inscripciones.size() >= disciplina.getMaximoParticipantes()) {
            throw new IllegalStateException("El torneo alcanzó el máximo de participantes.");
        }
        int participantesEmpresa = 0;

        for (Inscripcion inscripcion : inscripciones) {
            if (inscripcion.getParticipante().getCodigo()
                .equalsIgnoreCase(participante.getCodigo())) {
            throw new IllegalArgumentException(
                    "El participante ya está inscrito.");
            }
            if (inscripcion.getParticipante().getEmpresa() == participante.getEmpresa()) {
            participantesEmpresa++;
            }
        }

        if (participantesEmpresa >= 2) {
            throw new IllegalStateException("Una empresa no puede inscribir más de dos participantes.");
        }
            inscripciones.add(new Inscripcion(participante));
    }


    public void cerrarInscripciones() {
        if (estado != EstadoTorneo.EN_INSCRIPCION) {
            throw new IllegalStateException("Las inscripciones ya fueron cerradas.");
        }
        if (!disciplina.validarInscripcion(inscripciones.size())) {
            throw new IllegalStateException("No se cumple con el mínimo de participantes.");
        }
        generarEventos();
        estado = EstadoTorneo.EN_JUEGO;
    }

    public void generarEventos() {
    List<Evento> nuevosEventos = disciplina.crearEventos(inscripciones);
    if (nuevosEventos == null || nuevosEventos.isEmpty()) {
        throw new IllegalStateException(
            "No se pudieron generar los eventos.");
    }
        eventos.addAll(nuevosEventos);
    }

    public List<Inscripcion> obtenerTablaPosiciones() {
        List<Inscripcion> tabla = new ArrayList<>(inscripciones);
        Collections.sort(tabla);
        return tabla;
    }

    public void verificarFinalizacion() {
        if (estado != EstadoTorneo.EN_JUEGO || eventos.isEmpty()) {
            return;
        }
        for (Evento evento : eventos) {
            if (evento.getEstado() != EstadoEvento.FINALIZADO) {
                return;
            }
        }
        finalizarTorneo();
    }

    private void finalizarTorneo() {
        estado = EstadoTorneo.FINALIZADO;
        calcularPremio();
    }

    public void calcularPremio() {
        premio = disciplina.getCuota()
            .multiply(BigDecimal.valueOf(inscripciones.size()))
            .multiply(new BigDecimal("0.50"));
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public List<Inscripcion> getInscripciones() {
        return Collections.unmodifiableList(inscripciones);
    }

    public List<Evento> getEventos() {
        return Collections.unmodifiableList(eventos);
    }

    public EstadoTorneo getEstado() {
        return estado;
    }

    public BigDecimal getPremio() {
        return premio;
    }

    @Override
    public String toString() {
        return "Torneo: " + nombre
                + " | Código: " + codigo
                + " | Disciplina: " + disciplina.getNombre()
                + " | Participantes: " + inscripciones.size()
                + " | Estado: " + estado;
    }
}
