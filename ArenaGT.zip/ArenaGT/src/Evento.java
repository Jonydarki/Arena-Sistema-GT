
import java.time.LocalDate;
import java.util.Scanner;

public abstract class Evento implements Programable, Comparable<Evento> {
    public abstract boolean involucraParticipante(Participante participante);
    protected LocalDate fecha;
    protected int hora;
    protected String sede;
    protected EstadoEvento estado;
    public Evento() {
        this.fecha = null;
        this.hora = 0;
        this.sede = null;
        this.estado = EstadoEvento.SIN_PROGRAMAR;
    }

    @Override
    public void programar(LocalDate fecha, int hora, String sede) {
        if (estado != EstadoEvento.SIN_PROGRAMAR) {
            throw new IllegalStateException("El evento ya fue programado.");
        }
        validarDatosProgramacion(fecha, hora, sede);
        this.fecha = fecha;
        this.hora = hora;
        this.sede = sede;
        this.estado = EstadoEvento.PROGRAMADO;
    }

    @Override
    public void reprogramar(LocalDate fecha, int hora, String sede) {
        if (estado != EstadoEvento.PROGRAMADO) {
            throw new IllegalStateException(
                "Solo se pueden reprogramar eventos programados.");
        }
        validarDatosProgramacion(fecha, hora, sede);
        this.fecha = fecha;
        this.hora = hora;
        this.sede = sede;
    }

    private void validarDatosProgramacion(
            LocalDate fecha, int hora, String sede) {
        if (fecha == null) {
            throw new IllegalArgumentException("La fecha no puede ser nula.");
        }
        if (hora < 0 || hora > 23) {
            throw new IllegalArgumentException("La hora debe estar entre 0 y 23.");
        }
        if (sede == null || sede.trim().isEmpty()) {
            throw new IllegalArgumentException("La sede no puede estar vacía.");
        }
    }

    @Override
    public boolean estaProgramado() {
        return estado == EstadoEvento.PROGRAMADO;
    }

    protected void finalizarEvento() {
        estado = EstadoEvento.FINALIZADO;
    }

    public abstract void registrarResultado(Scanner scanner);

    public LocalDate getFecha() {
        return fecha;
    }

    public int getHora() {
        return hora;
    }

    public String getSede() {
        return sede;
    }

    public EstadoEvento getEstado() {
        return estado;
    }

    @Override
    public int compareTo(Evento otro) {
        int resultado = this.fecha.compareTo(otro.fecha);
        if (resultado == 0) {
            resultado = Integer.compare(this.hora, otro.hora);
        }

        if (resultado == 0) {
            resultado = this.sede.compareToIgnoreCase(otro.sede);
        }

        return resultado;
    }

    @Override
    public String toString() {
        return "Fecha: " + fecha
                + " | Hora: " + hora
                + ":00 | Sede: " + sede
                + " | Estado: " + estado;
    }
}
