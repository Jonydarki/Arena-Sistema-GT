import java.time.LocalDate;

public interface Programable {
    void programar(LocalDate fecha, int hora, String sede);
    void reprogramar(LocalDate fecha, int hora, String sede);
    boolean estaProgramado();
}