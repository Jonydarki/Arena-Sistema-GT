import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Relevos extends Disciplina {
    public Relevos() {
        super("Relevos", new BigDecimal("300"), 3, 8);
    }

    @Override
    public List<Evento> crearEventos(List<Inscripcion> participantes) {
    List<Evento> eventos = new ArrayList<>();
    eventos.add(new CarreraRelevos(new ArrayList<>(participantes)));
    return eventos;
    }
}