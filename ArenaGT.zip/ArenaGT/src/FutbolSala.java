
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class FutbolSala extends Disciplina {
    public FutbolSala() {
        super("Fútbol Sala", new BigDecimal("600"), 4, 8);
    }
    protected FutbolSala(String nombre, BigDecimal cuota) {
        super(nombre, cuota, 4, 8);
    }

    @Override
    public List<Evento> crearEventos(List<Inscripcion> participantes) {
        List<Evento> eventos = new ArrayList<>();
        for (int i = 0; i < participantes.size(); i++) {
            for (int j = i + 1; j < participantes.size(); j++) {
                eventos.add(new EncuentroFutbolSala(
                        participantes.get(i),
                        participantes.get(j)
                ));
            }
        }
        return eventos;
    }
}